//
// Created by Perfare on 2020/7/4.
//

#ifndef ZYGISK_IL2CPPDUMPER_GAME_H
#define ZYGISK_IL2CPPDUMPER_GAME_H

#define GamePackageName "com.game.packagename"

#endif //ZYGISK_IL2CPPDUMPER_GAME_H
